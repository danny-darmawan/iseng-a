const buku = require('./buku');

const getBuku = () => {
    return buku;
}

export { getBuku };